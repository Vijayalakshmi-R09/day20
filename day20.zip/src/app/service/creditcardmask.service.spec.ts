import { TestBed } from '@angular/core/testing';

import { CreditcardmaskService } from './creditcardmask.service';

describe('CreditcardmaskService', () => {
  let service: CreditcardmaskService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(CreditcardmaskService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
