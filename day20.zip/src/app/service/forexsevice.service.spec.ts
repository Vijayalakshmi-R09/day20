import { TestBed } from '@angular/core/testing';

import { ForexseviceService } from './forexsevice.service';

describe('ForexseviceService', () => {
  let service: ForexseviceService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(ForexseviceService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
