import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class CreditcardmaskService {

  constructor() { }
    getcredcardnumber(credcardno:string):string{
      return credcardno;
    }
}
