import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class UnitconversionService {

  constructor() { }
  public cmTomtr(units:number):number{
    return units/100;
  }
  public mtrTocm(units:number):number{
    return units*100;
  }
  public centigradeTofarh(units:number):number{
    return (units*2)+32;
  }
  public farhTocentigrade(units:number):number{
    return (units-32)/2;
  }
  public invalid(){
    alert("INVALID CONVERSION Tired")
  }
}

