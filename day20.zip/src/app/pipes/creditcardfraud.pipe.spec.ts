import { CreditcardfraudPipe } from './creditcardfraud.pipe';

describe('CreditcardfraudPipe', () => {
  it('create an instance', () => {
    const pipe = new CreditcardfraudPipe();
    expect(pipe).toBeTruthy();
  });
});
