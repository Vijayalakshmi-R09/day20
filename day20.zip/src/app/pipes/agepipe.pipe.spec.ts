import { AgepipePipe } from './agepipe.pipe';

describe('AgepipePipe', () => {
  it('create an instance', () => {
    const pipe = new AgepipePipe();
    expect(pipe).toBeTruthy();
  });
});
