import { Pipe, PipeTransform } from '@angular/core';

@Pipe({
  name: 'creditcardfraud'
})
export class CreditcardfraudPipe implements PipeTransform {

  transform(creditcard:string):string {
    const visibledig=4;
    let maskeddigits=creditcard.slice(0,-visibledig);
    let visibledigit=creditcard.slice(-visibledig);
    return maskeddigits.replace(/./g,'*')+visibledigit;
  }

}
