import { Component } from '@angular/core';
import { Frauddetails } from './frauddetails';
import { Payload } from './payload';
import { CreditcardmaskService } from './service/creditcardmask.service';
import { ForexseviceService } from './service/forexsevice.service';
import { FraudulentpaymentService } from './service/fraudulentpayment.service';
import { PaymentpayloadService } from './service/paymentpayload.service';
import { UnitconversionService } from './service/unitconversion.service';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  title = 'FOR_EX CALCULATION';
  convertFromvar:string='';
  convertTovar:string='';
  currency:number=0;
  val:number=0;
  fromunit:string='';
  tounit:string='';
  unit:number=0;
  unitval:number=0;
  age1:number=0
  credcardno:string='';
  payload:Payload[];
  fraudlist:Frauddetails[];
  constructor(private pload:PaymentpayloadService,private forex:ForexseviceService,
  private unitob:UnitconversionService,private credno:CreditcardmaskService,private fraud:FraudulentpaymentService){}
   
  convertFrom(event:any){
    this.convertFromvar=event.target.value;
  }
  convertTo(event:any){
    this.convertTovar=event.target.value;
  }
  convert()
  {
    if(this.convertFromvar=="INR" && this.convertTovar=="USD"){
      this.currency=this.forex.inrTousd(this.val);
    }
    else if(this.convertFromvar=="INR" && this.convertTovar=="EURO"){
      this.currency=this.forex.inrToeuro(this.val);
    }
    else if(this.convertFromvar=="USD" && this.convertTovar=="INR"){
      this.currency=this.forex.usdToinr(this.val);
    }
    else if(this.convertFromvar=="USD" && this.convertTovar=="EURO"){
      this.currency=this.forex.usdToeuro(this.val);
    }
    else if(this.convertFromvar=="EURO" && this.convertTovar=="INR"){
      this.currency=this.forex.euroToinr(this.val);
    }
    else if(this.convertFromvar=="EURO" && this.convertTovar=="USD"){
      this.currency=this.forex.euroTousd(this.val);
    }
    else{
      this.currency=this.val;
      console.log("Invalid Conversion");
    }
  }
  unitFrom(event:any){
    this.fromunit=event.target.value;
  }
  unitTo(event:any){
    this.tounit=event.target.value;
  }
  unitconvert()
  {
    if(this.fromunit=='cm' && this.tounit=='mtr'){
      this.unit=this.unitob.cmTomtr(this.unitval)
    }
    else if(this.fromunit=='mtr' && this.tounit=='cm'){
      this.unit=this.unitob.mtrTocm(this.unitval)
    }
    else if(this.fromunit=='centigrade' && this.tounit=='Fahrenheit'){
      this.unit=this.unitob.centigradeTofarh(this.unitval)
    }
    else if(this.fromunit=='Fahrenheit' && this.tounit=='centigrade'){
      this.unit=this.unitob.farhTocentigrade(this.unitval)
    }
    else{
      this.unitob.invalid();
    }
  }
  show(){
    console.log("Details listed...")
    this.pload.display().then((data)=>{
      this.payload=data;
      console.log(data)
    })
  }
  display()
  {
    this.fraud.display().then((data)=>
    {
     this.fraudlist=data;
     console.log(data)
    });
  }
}

