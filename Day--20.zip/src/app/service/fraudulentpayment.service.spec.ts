import { TestBed } from '@angular/core/testing';

import { FraudulentpaymentService } from './fraudulentpayment.service';

describe('FraudulentpaymentService', () => {
  let service: FraudulentpaymentService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(FraudulentpaymentService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
