import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class ForexseviceService {

  constructor() { }
  public inrTousd(cur:number):number{
    return cur*0.01373;
  }
  public inrToeuro(cur:number):number{
    return cur*0.012;
  }
  public usdToinr(cur:number):number{
    return cur*72.69;
  }
  public usdToeuro(cur:number):number{
    return cur*0.84;
  }
  public euroToinr(cur:number):number{
    return cur*86.63;
  }
  public euroTousd(cur:number):number{
    return cur*1.19;
  }
}
