import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Frauddetails } from '../frauddetails';

@Injectable({
  providedIn: 'root'
})
export class FraudulentpaymentService {
  dburl="http://localhost:3000/fraud";
  constructor(private http:HttpClient) { }
  display():Promise<Frauddetails[]>
  {
    return this.http.get<Frauddetails[]>(this.dburl).toPromise();
  }
}
