import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Payload } from '../payload';

@Injectable({
  providedIn: 'root'
})
export class PaymentpayloadService {
  dburl="http://localhost:3000/paylaod";
  constructor(private paylod:HttpClient) {
   }
   display():Promise<Payload[]>{
    return this.paylod.get<Payload[]>(this.dburl).toPromise();
   }

}
