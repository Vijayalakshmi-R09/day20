export interface Payload {
      id:number,
      Customerid:string,
      PaymentAmount:number,
      Currency:string,
      fromAccount:string,
      ToAccount:string,
      BeneficiaryAccount:string,
      Bankcharges:number
}
