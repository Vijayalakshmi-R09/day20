export interface Frauddetails {
    Country_Id:number,
    Customer_Type:string,
    BannedCurrency:string,
    AmountLimit:number,
    BlockedAccount:number,
    ExpiryDate:number,
    Country:string
}
